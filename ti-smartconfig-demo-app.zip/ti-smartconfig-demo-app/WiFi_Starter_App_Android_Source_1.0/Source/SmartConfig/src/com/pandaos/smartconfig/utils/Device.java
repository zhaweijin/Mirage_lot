//
//  Copyright (c) 2014 Texas Instruments. All rights reserved.
//

package com.pandaos.smartconfig.utils;

public class Device {
	public String name;
	public String host;
	
	public Device(String name, String host) {
		this.name = name;
		this.host = host;
	}
}
